$(function(){
	$("#play").click(playNewGame);

	setTimeout(function(){
		$("#play").click();
	}, 5000);
});


function playNewGame(){
	alert("Yeah! New Game with WAP!");
}






