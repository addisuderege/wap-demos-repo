document.getElementById("ok").onclick = okayClick;
function okayClick() {
    alert("booyah");
}
