(function () {

    window.onload = function () {
        var mainDiv = document.getElementById("main");
        var icon = document.getElementById("icon");

        console.log("mainDiv tagName: " + mainDiv.tagName);
        console.log("mainDiv className: " + mainDiv.className);
        console.log("mainDiv innerHTML: " + mainDiv.innerHTML);
        console.log("icon src: " + icon.src);



    };
})();


